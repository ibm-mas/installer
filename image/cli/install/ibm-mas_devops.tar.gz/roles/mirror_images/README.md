mirror_images
=================

Supports mirroring specific images to the target mirror registry