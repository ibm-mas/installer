ansible_version_check
======================

Internal-use role that all other roles in the collection declare a dependency upon to ensure that the minimum supported level of Ansible is used.

License
-------

EPL-2.0
